var e=(Promise.withResolvers||function(){var e,r,s=new this((s,i)=>{e=s,r=i});return{resolve:e,reject:r,promise:s}}).bind(Promise);export{e as w};
