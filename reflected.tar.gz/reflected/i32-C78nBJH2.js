var r=r=>{const n=new Int32Array(1);return()=>n[0]++};export{r as i};
